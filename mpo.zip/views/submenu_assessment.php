<div class="submenu">
    <div class="container d-flex justify-content-between">
        <h3 class="text-black">Үнэлгээ</h3>
        <ul class="submenu-ul">
            <li><a href="assessment_nuat">Нэмэгдэсэн өртөг</a></li>
            <li><a href="#">5C</a></li>
            <li><a href="#" title="Бизнесийн төгөлдөршлийн тасралтгүй сайжруулалтын үнэлгээ">БТТСҮ</a></li>
            <li><a href="assessment_iso">ISO9001:2015</a></li>
            <li><a href="assessment_tb" title="ТӨРИЙН БАЙГУУЛЛАГЫН БҮТЭЭМЖИЙН ГҮЙЦЭТГЭЛИЙН ТҮВШИН ТОГТООХ АСУУЛГА">Төрийн байгууллага</a></li>
            <li><a href="assessment_jdu" title="ЖДҮ-ийн бүтээмж, сайжруулалтын хөтөлбөрийн анхан шатны үнэлгээ">ЖДҮ</a></li>
            <li><a href="assessment_bt" title="БИЗНЕСИЙН ТӨГӨЛДӨРШЛИЙН ТАСРАЛТГҮЙ САЙЖРУУЛАЛТЫН ҮНЭЛГЭЭ">Төгөлдөршил</a></li>
            <li><a href="#">Экспертүүд</a></li>
        </ul>
    </div>
</div>
